package arrayName;
	class Main 
	{
		 public static void main(String[] args) 
		 {
		   int[] a = {24, 45, 39, 22, 50}; 
		   {
		   System.out.println("First Element: " + a[0]);
		   System.out.println("Second Element: " + a[1]);
		   System.out.println("Third Element: " + a[2]);
		   System.out.println("Fourth Element: " + a[3]);
		   System.out.println("Fifth Element: " + a[4]);
		   }
		 }
		 
	}