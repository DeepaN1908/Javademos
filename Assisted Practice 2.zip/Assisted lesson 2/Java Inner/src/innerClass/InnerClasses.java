package innerClass;
class Demo {
    void show()
    {
        System.out.println("Welcome to Java Inner Class");
    }
}
class Demo1 {
    static Demo d = new Demo() {
        void show()
        {
            super.show();
            System.out.println("Anonymous Class");
        }
    };
    public static void main(String[] args)
    {
        d.show();
    }
}