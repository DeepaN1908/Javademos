
public class TypeCasting {

	public static void main(String[] args) {
				System.out.println("Implicit TypeCasting");
				char a='A';
				System.out.println("Value of a: "+a);
				
				int b=a;
				System.out.println("Value of b: "+b);
				
				float c=a;
				System.out.println("Value of c: "+c);
				
				long d=a;
				System.out.println("Value of d: "+d);
				
				double e=a;
				System.out.println("Value of e: "+e);
				
						
				System.out.println("\n");
				
				System.out.println("Explicit TypeCasting");
				
				double m=85.5;
				int n=(int)m;
				System.out.println("Value of m: "+m);
				System.out.println("Value of n: "+n);
	}
}

